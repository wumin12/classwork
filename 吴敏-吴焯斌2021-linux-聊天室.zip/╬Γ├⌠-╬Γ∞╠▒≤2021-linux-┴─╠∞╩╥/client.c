#include"public.h"
#define SIZE 50
pthread_t tid1;
char g_name[NAME_LEN];
int  g_locate;
int  g_total;

//为了安全的输入（防止暴力输入）
char get_choice();	
long get_tele();
char get_first();
char getch();
char * s_gets(char * st, int n);
void secret_pwd(char * pwd);
//具体功能实现函数
void create_user_file();
void register_user();
void login();
void find_pwd();
//加密解密函数
void encipher(char * original);
void decipher(char * cipher);
//菜单函数
void show_line(const char * line);
void user_menu();
void sock1();

typedef struct user		//用户信息主体
{
	char id[SIZE];		//账号
	char pwd[SIZE];		//密码
	long tele;		//电话号码
}user;
//保证文件users的存在，该文件存在时也不清空其中的数据
void create_user_file()
{
	FILE * fp;

	if ((fp = fopen("users", "r")) == NULL)	
	{
		if ((fp = fopen("users", "w+")) == NULL)
		{
			fprintf(stderr, "无法打开用户信息!\n");
			system("sleep 3s");
			return;
		}
	}
	fclose(fp);

	return;
}
//显示主界面并获取用户键入的信息
char get_choice(void)
{
	char ch;

	ch =get_first();
	while(ch != 'a' && ch != 'b' && ch != 'c' && ch != 'q')
	{
		puts("请输入正确选项");
		ch =get_first();
	}

	return ch;
}
//返回键入的第一个字母字符并清空缓存区
char get_first(void)
{
    	char ch = 0;
	while (!isalpha(ch = getchar()))
        	continue;
		while (getchar() != '\n')
			continue;

    	return tolower(ch);	 //返回小写值
}
//注册函数
void register_user()
{
	FILE * fp;
	user new_, old;		//这里new后面多'_'的原因是c++有个关键字是new
	char temp[SIZE]; 

	show_line("请开始注册您的账号!");
	
	if ((fp = fopen("users", "r")) == NULL)
	{
		fprintf(stderr, "读取用户信息失败！\n");
		system("sleep 3s");
		return;
	}
	puts("请输入您的账号：");
	s_gets(new_.id, SIZE);
	while (!feof(fp))
	{
		fread(&old, sizeof(user), 1, fp);
		decipher(old.pwd);
		if (!strcmp(new_.id, old.id))
		{
			fprintf(stderr, "账号重复！\n");
			system("sleep 3s");
			return;
		}
	}
	puts("请输入您的密码：");
	secret_pwd(new_.pwd);
	puts("请再次输入您的密码：");
	secret_pwd(temp);
	while (1)
	{
		if (!strcmp(new_.pwd, temp))
			break;
		puts("两次密码不一致！");
		puts("请重新输入您的密码：");
		secret_pwd(new_.pwd);
		puts("请再次输入您的密码：");
		secret_pwd(temp);
	}
	puts("请输入您的电话号码以便找回密码：");
	new_.tele = get_tele();
	fp = fopen("users", "a");
	encipher(new_.pwd);
	fwrite(&new_, sizeof(user), 1, fp);
	printf("账号%s已注册成功！\n", new_.id);
	system("sleep 3s");
	
	fclose(fp);
	return;
}
//安全地获取电话号码
//64位架构下long最大值是9223372036854775807，用来存储电话号码很合适
long get_tele()
{
	long input;
	char ch;

	while (scanf("%ld", &input) != 1) 
	{
		while ((ch =getchar()) != '\n')
			putchar(ch);
		printf(" 不是一个电话号码！\n请您重新输入：\n");
	}

	return input;
}
//登录函数
void login()
{
	FILE * fp;
	user old;
	char temp[SIZE];

	show_line("请开始登录您的账号！");

	if ((fp = fopen("users", "r")) == NULL)
	{
		fprintf(stderr, "读取用户信息失败！\n");
		system("sleep 3s");
		return;
	}
	puts("请输入您的账号：");
	s_gets(temp, SIZE);
	while (!feof(fp))	//判断是否到达文件结尾
	{
		fread(&old, sizeof(user), 1, fp);
		decipher(old.pwd);
		if (!strcmp(temp, old.id))
		{
			puts("请输入您的密码：");
			secret_pwd(temp);
			if (!strcmp(temp, old.pwd))
			{
				show_line("登录成功！");
				system("sleep 2s");	//休眠
				sock1();
			}
			else
			{
				puts("密码不匹配！");
				system("sleep 3s");
				return;
			}
		}
	}
	printf("账号%s不存在！\n", temp);
	system("sleep 3s");

	fclose(fp);
	return;
}
//找回密码函数
void find_pwd()
{
	FILE * fp;
	user old;
	char temp[SIZE];
	long key;

	show_line("请开始找回您的密码!");

	if ((fp = fopen("users", "r")) == NULL)
	{
		fprintf(stderr, "读取用户信息失败！\n");
		system("sleep 3s");
		return;
	}

	puts("请输入您的账号：");
	s_gets(temp, SIZE);
	while (!feof(fp))
	{
		fread(&old, sizeof(user), 1, fp);
		decipher(old.pwd);
		if (!strcmp(temp, old.id))
		{
			puts("请输入您的电话号码：");
			if ((key = get_tele()) == old.tele)
				printf("您的密码是：%s\n", old.pwd);
			else
				puts("电话号码不匹配！");
			system("sleep 3s");
			return;
		}
	}
	printf("账号%s不存在！\n", temp);
	system("sleep 3s");

	fclose(fp);
	return;
}

char * s_gets(char * st, int n)
{
	char * ret_val;
	int i = 0;

	ret_val = fgets(st, n, stdin);
	if (ret_val != NULL)
	{
		while (st[i] != '\0' && st[i] != '\n')
			i++;
		if (st[i] == '\n')
			st[i] = '\0';
		else
			while (getchar() != '\n')
				continue;
	}
	return ret_val;
}
//自定义的getch()函数
char getch()
{
	char ch;

    	system("stty -echo");
    	system("stty -icanon");
    	ch = getchar();
    	system("stty icanon");
    	system("stty echo");

    	return ch;
}

void secret_pwd(char * pwd)
{
	char ch;
	int i = 0;

	while ((ch = getch()) != '\n')
	{
		if (ch == '\x7F')
		{
			putchar('\b');
			putchar(' ');
			putchar('\b');
			if (i)
				i--;
			else
				putchar('\a');
		}
		else
		{
			putchar('*');
			pwd[i++] = ch;
		}
	}
	pwd[i] = '\0';
	putchar('\n');
	return;
}
//加密函数
void encipher(char * original)
{
    	int key = 1;
    	int i=0;
    	for (; i < strlen(original); i++)
    	{
		original[i] += key;
		key=-key;
    	}

	return;
}
//解密函数
void decipher(char * cipher)
{
    	int key = -1;
    	int i = 0;
    	for (; i < strlen(cipher); i++)
    	{
        	cipher[i] += key;
        	key = -key;
    	}

	return;
}
//展示某句话
void show_line(const char * line)
{
	system("clear");	//清屏函数
	int i =0;
	for (; i < 40;i++)
		putchar('*');
	putchar('\n');
	printf("\n%s\n\n", line);
	for (; i < 40;i++)
		putchar('*');
	putchar('\n');	

	return;
}

void user_menu()
{
	char choice;			//记录get_choice()返回值

	show_line("欢迎使用Linux版登录系统!");
//用字符串来输出是一个比较好用的技巧，来保证对齐
    	printf("\n%-20s%-20s\n%-20s%-20s\n\n", "a. 注册账号", "b. 登录账号", "c. 找回密码", "q. 退出登录");
	int i =0;
	for (; i < 40;i++)
		putchar('*');
	putchar('\n');
	create_user_file();
	while ((choice = get_choice()) != 'q')
	{
		switch(choice)
		{
			case 'a': register_user();
					  break;
			case 'b': login();
					  break;
			case 'c': find_pwd();
					  break;
		}
		show_line("欢迎使用Linux版登录系统!");
	   	printf("\n%-20s%-20s\n%-20s%-20s\n\n", "a. 注册账号", "b. 登录账号", "c. 找回密码", "q. 退出登录");
		for (; i < 40;i++)
		putchar('*');
     	putchar('\n');
	}

	return;
}
void flush(){ char c; do{c=getc(stdin);}while(c!='\n'&&c!=EOF);};
int CheckExist()
{

	int i;
	for(i=0;i<MAX_CLIENT;i++)
	{

		if(!strcmp(g_name,clientList[i].name))
			break;
	}

	if(i<MAX_CLIENT)
	{
		printf("this name: %s is already exist!!\n",g_name);
		return 1;
	}
	else
		return 0;
}

void  ShowList()
{
int i;
g_total=0;
	printf("\t _____________________________ \n");
        printf("\t|         CLIENT LIST         |\n");
        printf("\t|_____________________________|\n");
	printf("\t|\e[4m  sort   |      name         \e[24m|\n ");
        // printf("\t|_________|___________________|\n");
  	for(i=0;i<MAX_CLIENT;i++)
  	{

    		if(clientList[i].socketFd!=0)
    		{
	      		if(i==g_locate)
			{
				printf("\t|\e[4;31m *%-4d   |  %-10s       \e[0m|\n",++g_total,clientList[i].name);
                	 //printf("\t|_________|___________________|\n");
		   	}
		   	else
		   	{
		        	printf("\t|\e[4m   %-4d  |  %-10s       \e[24m|\n",++g_total,clientList[i].name);
             			//    printf("\t|_________|___________________|\n");
		   	}
    		}
   	}	

        printf("\t|\e[4m                Total:%-3d    \e[24m|\n",g_total);
}

int MakeTempList(int *tmp)
{
	int i,n=0;
	for(i=0;i<MAX_CLIENT;i++)
	{
	if(clientList[i].socketFd!=0)
     	{	tmp[n]=i; n++; }
	}
	ShowList();

	int select;
	printf("please select the user \n");
	if(1!=scanf("%d",&select))
	{
		flush();
		printf("bad select \n");
		return -1;
	}
	if(select<=g_total)    
	{
		if(tmp[select-1]==g_locate)
		{
			printf("\e[33m#SYSTEM:YOU CAN NOT SELECT YOURSELF\e[0m\n");
			return -1;
		}
		else
			return tmp[select-1];
	}
	else
	{
		printf("bad select \n");
		return -1;
	}

}

void *RecvMsg(void *fd)
{

	int sockfd=*(int *)fd;
	MESSAGE msg;
    
	while(1)
	{
		bzero(&msg,sizeof(msg)); msg.type=ERROR;
		read(sockfd,&msg,sizeof(msg));
		if(msg.type==ERROR)
			break;
		switch(msg.type)
		{

         	case LOGIN:
			 if(msg.fromUserLocate==g_locate)
			 printf("\e[34m######  > loing succeed\e[0m\n");
			 else
			 printf("\e[33m#LOGIN  > From:%-10s Msg:%s\e[0m\n",msg.fromUser,msg.message);
			 break;
		case EXIT:
			 printf("\e[33m#EXIT   > From:%-10s Msg:%s\e[0m\n",clientList[msg.fromUserLocate].name,msg.message);
			 break;
		case PUBLIC:
			 printf("\e[32m#PUBLIC > From:%-10s Msg:%s\e[0m\n",msg.fromUser,msg.message);
			 break;
		case PRIVATE:
			 printf("\e[31m#PRIVATE> From:%-10s Msg:%s\e[0m\n",msg.fromUser,msg.message);
			 break;
		default:break;
		
		}
		memcpy(&clientList,&msg.clientList,sizeof(clientList));

	}
	
	printf("server is breakdown \n");
	exit(1);

}

void SendMsg(int fd)
{
 	
	MESSAGE msg;
    	msg.type=LOGIN;
	msg.fromUserLocate=g_locate;
	strcpy(msg.fromUser,g_name);
	strcpy(msg.message,g_name);
	write(fd,&msg,sizeof(msg));

	int tmp[MAX_CLIENT];
	int  key;
	while(1)
	{  

        	printf(" 1 public  2 private 3 EXIT 4 client list\n");
		if(1!= scanf("%d",&key))
		{
		key=0;
	        flush();
		}
		bzero(&msg,sizeof(msg));
	    	strcpy(msg.fromUser,g_name);
       		msg.fromUserLocate=g_locate;
		switch(key)
		{

           		case 1:
              			msg.type=PUBLIC;
			   	printf("\npublic: please input content \n");
	            		flush();
			   	fgets(msg.message,sizeof(msg.message),stdin);
			   	msg.message[strlen(msg.message)-1]='\0';
               			write(fd,&msg,sizeof(msg));
			   	break;
		   	case 2:
			   	bzero(tmp,sizeof(tmp));
			   	msg.type=PRIVATE;
			   	if(-1!=(msg.sendUserLocate=MakeTempList(tmp)))
			   	{ 
				printf("\nprivate: please input content \n");
	            		flush();
			    	fgets(msg.message,sizeof(msg.message),stdin);
			    	msg.message[strlen(msg.message)-1]='\0';
                		write(fd,&msg,sizeof(msg));
			   	}
			  	break;
		  	 case 3:
			   	printf("EXIT \n");
               			msg.type=EXIT;
			   	strcpy(msg.message,"bye-bye");
               			write(fd,&msg,sizeof(msg));
		 		break;
		   	 case 4:
			   	ShowList();
			   	break;
		   	 default:
			   	printf("bad select  \n");
              			msg.type=0;
			   	break;
		}
	    	if(msg.type==EXIT)
		{
			break;
		}
	}
   	pthread_cancel(tid1);
}


void sock1()
{
	int fd;
	char ip[20]="127.0.0.1";
	struct sockaddr_in addr;
	addr.sin_port=htons(PORT);
	addr.sin_family=AF_INET;
  	addr.sin_addr.s_addr=inet_addr(ip);
   
	if(-1==(fd=socket(AF_INET,SOCK_STREAM,0)))
	{
		perror("socket error");
		exit(1);
	}
   
	if(-1==(connect(fd,(struct sockaddr*)&addr,sizeof(struct sockaddr))))
	{
		perror("connect error");
		exit(2);
	}

   	MESSAGE msg;

   	read(fd,&msg,sizeof(msg));
   
  	if(msg.type==EXIT)
   	{
		printf("service refuse connect \n");
		exit(1);
   	}
   	else
   	{

		memcpy(&clientList,&msg.clientList,sizeof(clientList));
   		g_locate=msg.fromUserLocate;
   		pthread_create(&tid1,NULL,RecvMsg,(void *)&fd);
   		do{
   			printf("please input your chat name\n");scanf("%s",g_name);
     		}while(CheckExist());
   		SendMsg(fd);
   
   		pthread_join(tid1,NULL);
   	}
}

int main()
{
	user_menu();
	return 0;
}
		

